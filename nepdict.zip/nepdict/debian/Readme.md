NepDict is a English-Nepali Dictionary which could be used in order to know the Nepali meaning of an English Word for better understanding.

* We have Online Dictionary for regular users at "www.nepdict.com"
* We have Command based Offline Dictionary too.

```
## Version 
* Version 1.1

##md5sum
* 531e6cf28997deb92219c8448010bdd2  nepdict.py
* 15d44b3cac28e05321d22a7ffc333c8a  Nepdict.desktop
* 62f9e4a37d599cb91219d2761b4bf746  nepdict.png

## Contact

* Homepage: www.nepdict.com
* E-Mail: info@nepdict.com
*Facebook: facebook.com/nepdict
* // Developer //
* Name: Nirooj Bista
* Website: http://www.nirojbista.com.np
* E-mail: info@nirojbista.com.np
* Facebook:- https://www.facebook.com/niroj56
* Twitter:- https://www.twitter.com/nirooj56
* Google Plus:- https://plus.google.com/+bistanirooj
* Linkedin:- https://www.linkedin.com/in/nirooj56
